@include('header') 
<div class="catergory-section">
    <div class="category-data">
    
     
       <div class="category-link cat_01">{{@$data->title}}</div>
        <div class="category-link cat_02">i{{@$data->description}}</div>
        
        
</div>
@include('footer') 
